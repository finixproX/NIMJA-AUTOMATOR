import "dotenv/config";
import express from "express";
import rateLimit from "express-rate-limit";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createPaymentRequest, getPaymentMode, getPaymentStatus, listPaymentTransactions, simulatePaymentResult } from "./payment-service.js";

const app = express();
const here = path.dirname(fileURLToPath(import.meta.url));
app.disable("x-powered-by");
app.use((_req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
  next();
});
app.use(express.json({ limit: "10kb", strict: true }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: "draft-7", legacyHeaders: false }));
app.use("/api/payment", rateLimit({ windowMs: 60_000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false }));

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "FOYSAL AUTOMATOR", version: "6.2.0", mode: "local-assistant" }));
app.get("/api/payment/config-status", (_req, res) => {
  const mode = getPaymentMode();
  res.json({
    mode,
    configured: mode === "sandbox",
    livePaymentEnabled: false,
    message: mode === "sandbox"
      ? "Sandbox simulation only. No real payment is processed."
      : "Live payment is disabled until an official, authorized provider API contract is implemented."
  });
});
app.post("/api/payment/create", (req, res, next) => {
  try {
    const transaction = createPaymentRequest(req.body);
    return res.status(201).json({ ok: true, transaction });
  } catch (error) {
    if (error.status) return res.status(error.status).json({ ok: false, error: error.message });
    return next(error);
  }
});
app.get("/api/payment/transactions", (_req, res) => {
  res.json({ mode: getPaymentMode(), transactions: listPaymentTransactions() });
});
app.get("/api/payment/status/:id", (req, res) => {
  const transaction = getPaymentStatus(req.params.id);
  if (!transaction) return res.status(404).json({ ok: false, error: "Transaction not found in this running server session" });
  return res.json({ ok: true, transaction });
});
app.post("/api/payment/sandbox/:id/result", (req, res, next) => {
  try {
    const transaction = simulatePaymentResult(req.params.id, req.body?.outcome);
    if (!transaction) return res.status(404).json({ ok: false, error: "Transaction not found in this running server session" });
    return res.json({ ok: true, transaction });
  } catch (error) {
    if (error.status) return res.status(error.status).json({ ok: false, error: error.message });
    return next(error);
  }
});
// Backward-compatible explicit disabled endpoint; never contacts a provider.
app.post("/api/payment/link", (_req, res) => res.status(501).json({
  error: "Not implemented",
  message: "No payment request was sent. Live IVAC payment requires an official, authorized provider API specification."
}));
app.use(express.static(path.join(here, "public"), { etag: true, maxAge: "1h" }));
app.use((req, res) => res.status(404).json({ error: "Not found" }));
app.use((err, _req, res, _next) => {
  if (err?.type === "entity.too.large") return res.status(413).json({ error: "Request body too large" });
  if (err instanceof SyntaxError && "body" in err) return res.status(400).json({ error: "Invalid JSON body" });
  console.error("Request failed:", err?.message || "Unknown error");
  return res.status(500).json({ error: "Internal server error" });
});
const port = Number(process.env.PORT || 3000);
app.listen(port, "127.0.0.1", () => console.log(`FOYSAL AUTOMATOR v6.2 SLOT WATCH running at http://127.0.0.1:${port}`));
