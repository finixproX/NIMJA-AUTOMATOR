FOYSAL AUTOMATOR v6.2 — SLOT WATCH + LOCAL REMINDERS

WHAT IS NEW IN v6.2
- Slot Watch page records centre, observed status, optional date/time, note and timestamp.
- Records are stored locally in the browser and limited to the latest 100 observations.
- Manual re-check reminder with optional browser notification. Reminder requires the dashboard to remain open; long delays may be limited by the browser/OS.
- Existing profiles, checklist, activity log, backup import/export and security controls retained.

IMPORTANT SCOPE
This is an independent local planning assistant, not an official IVAC product. It does NOT log in, inspect live slots, scrape the portal, bypass CAPTCHA/queues, read OTPs, submit bookings, or create payments. Slot Watch records only what you manually observe. A slot marked “shown” is not a guarantee; verify it on the official portal.

RUN ON ANDROID TERMUX
1. pkg update && pkg install nodejs unzip -y
2. Extract the ZIP and enter the folder containing package.json and server.js.
3. npm install
4. npm run check
5. npm start
6. Open Chrome at http://127.0.0.1:3000

If extraction prompts to replace files, use `unzip -o FILE.zip` to overwrite without prompts. Do not type shell commands until extraction finishes and the `$` prompt returns.

PRIVACY / SECURITY
Profiles, checklist, activity, and Slot Watch records are stored in browser localStorage and are not encrypted. Do not store passport numbers, documents, passwords, OTPs or payment credentials. The server binds to 127.0.0.1 by default. Do not expose this prototype publicly without authentication, HTTPS and a security review.

PAYMENT
Payment creation remains disabled (HTTP 501) until a verified official provider API specification and authorization are available.

CHECKS
Run `npm run check` for server syntax validation. This build has not been tested against a live IVAC service; it has no live IVAC integration.


V6.3 CHANGELOG
- Removed the IVAC portal open/copy buttons from the dashboard and Slot Watch.
- Added Cloudflare DNS helper: Android Private DNS hostname one.one.one.one and IPv4 resolvers 1.1.1.1 / 1.0.0.1.
- DNS settings must be applied in Android Settings; a local web app cannot change system DNS settings.
- Cloudflare DNS does not guarantee IVAC availability and does not bypass server queues or access controls.


V6.5 BGD AUTO-READ:
- Profile BGD upload attempts local text extraction for applicant name and IVAC centre labels.
- Values are best-effort and must be verified; unknown/binary/encrypted BGD formats may not be readable without a sample and format-specific parser.
- The file is stored locally in this browser; it is not uploaded to IVAC.
