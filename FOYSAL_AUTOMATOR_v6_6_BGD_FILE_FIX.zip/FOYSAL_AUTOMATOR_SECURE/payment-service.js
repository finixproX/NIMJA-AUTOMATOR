import { randomUUID } from "node:crypto";

// Safe local sandbox only. This module does not contact IVAC or any payment provider.
const transactions = new Map();
const allowedPurposes = new Set(["appointment_fee", "service_fee", "test"]);

export function getPaymentMode() {
  return process.env.PAYMENT_MODE === "sandbox" ? "sandbox" : "disabled";
}

export function createPaymentRequest(body = {}) {
  if (getPaymentMode() !== "sandbox") {
    const error = new Error("Payment creation is disabled. Configure sandbox mode for local testing, or implement an officially authorized provider integration.");
    error.status = 503;
    throw error;
  }

  const amount = Number(body.amount);
  const currency = String(body.currency || "BDT").toUpperCase();
  const purpose = String(body.purpose || "test");

  if (!Number.isFinite(amount) || amount <= 0 || amount > 1000000) {
    const error = new Error("amount must be a positive number no greater than 1,000,000");
    error.status = 400;
    throw error;
  }
  if (!/^[A-Z]{3}$/.test(currency)) {
    const error = new Error("currency must be a 3-letter currency code");
    error.status = 400;
    throw error;
  }
  if (!allowedPurposes.has(purpose)) {
    const error = new Error("purpose must be appointment_fee, service_fee, or test");
    error.status = 400;
    throw error;
  }

  const id = `sandbox_${randomUUID()}`;
  const tx = {
    id,
    mode: "sandbox",
    amount: Math.round(amount * 100) / 100,
    currency,
    purpose,
    status: "PENDING",
    createdAt: new Date().toISOString(),
    note: "Simulation only. No money was charged and no IVAC request was sent."
  };
  transactions.set(id, tx);
  return { ...tx };
}

export function getPaymentStatus(id) {
  const tx = transactions.get(id);
  return tx ? { ...tx } : null;
}

// Explicitly simulated outcome for local UI testing; never marks a real payment paid.
export function simulatePaymentResult(id, outcome) {
  if (getPaymentMode() !== "sandbox") {
    const error = new Error("Sandbox simulation is disabled");
    error.status = 503;
    throw error;
  }
  if (!new Set(["PAID", "FAILED"]).has(outcome)) {
    const error = new Error("outcome must be PAID or FAILED");
    error.status = 400;
    throw error;
  }
  const tx = transactions.get(id);
  if (!tx) return null;
  tx.status = outcome;
  tx.updatedAt = new Date().toISOString();
  tx.note = "Simulated status only. This is not proof of a real payment.";
  return { ...tx };
}

export function listPaymentTransactions() {
  return [...transactions.values()].map((tx) => ({ ...tx })).reverse();
}
